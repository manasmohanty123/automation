package com.tegile.intelliflash.init;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class Constants {
	
	public static StringBuilder sb = new StringBuilder();
	public static FileWriter fWriter = null;
	public static BufferedWriter writer = null;

}
