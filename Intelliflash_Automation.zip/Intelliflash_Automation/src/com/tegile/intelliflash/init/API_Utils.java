package com.tegile.intelliflash.init;

import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.authentication.PreemptiveBasicAuthScheme;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;

public class API_Utils {
	String ssh_userName=Init.propConfig.getProperty("TestWorkBooks");
	String ssh_password=Init.propConfig.getProperty("TestWorkBooks");
	String ip=Init.propConfig.getProperty("ssh_IpAdress");
	static String projectId=null;
	static String versionId=null;
	static String cycleName=null;
	
	Response resp=null;
	static String jiraUserName=Init.propConfig.getProperty("jira_userName");
	static String jiraPassword=Init.propConfig.getProperty("jira_password");
	
	public  Response PostWithBasicAuth(String API_endPoint,String a_body) throws IOException
			{   
		
			    RestAssured.baseURI ="https://"+ip+a_body;
				
				try{
					 
					 resp= given().auth().preemptive().basic(ssh_userName,ssh_password).body(a_body).when().post();
			    
				}
				catch(Exception e)
				{
					return resp;
					
				}
			  return resp;
			}
	
	public  Response getWithBasicAuth(String API_endPoint,String a_body) throws IOException
	{   
  
	    RestAssured.baseURI ="https://"+ip+a_body;
		
		try{
			 
			 resp= given().auth().preemptive().basic(ssh_userName,ssh_password).body(a_body).when().get();
	    
		}
		catch(Exception e)
		{
			return resp;
			
		}
	  return resp;
	}
	
	public static Response doGetRequest(String endpoint) {

        PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
        authScheme.setUserName(jiraUserName);
        authScheme.setPassword(jiraPassword);
        RestAssured.authentication = authScheme;
        return
                given().
                        when().get(endpoint).
                        then().contentType(ContentType.JSON).extract().response();
    }

	public static String getProject() throws IOException {
		     String projectName=Init.propConfig.getProperty("ProjectName");
             Response r = doGetRequest("https://jira.tegile.com:8443/rest/api/2/project");
             List<String> a=r.path("key");
		    List<String> b=r.path("id");
		    for (int i = 0; i < a.size(); i++) {
				if(a.get(i).trim().equalsIgnoreCase(projectName))
				{
					projectId=b.get(i);
				}
			}
			return projectId;
	}
	
	public static String getVersionID() throws IOException {
		     String projectName=Init.propConfig.getProperty("ProjectName");
	         String versionNo=Init.propConfig.getProperty("VersionName");
             Response r = doGetRequest("https://jira.tegile.com:8443/rest/api/2/project/"+projectName+"/versions");
             List<String>lst1=r.path("name");
             List<String>lst2=r.path("id");
             for (int i = 0; i < lst1.size(); i++) {
            	 if(lst1.get(i).equals(versionNo))
            	 {
            		 versionId=lst2.get(i);
            	 }
				
			}
			return versionId;
	}
public static String getCycleName() throws IOException {
		String cycleName=Init.propConfig.getProperty("VersionName");
		Response r=doGetRequest("https://jira.tegile.com:8443/rest/zapi/latest/cycle?projectId="+getProject()+"&versionId="+getVersionID()+"");
		String [] arr=r.getBody().asString().split("started");
		for (int i = 0; i < arr.length; i++) {
			if(arr[i].contains(cycleName))
			{
				cycleName=arr[i].substring(7, 10);
			}
		}
		return cycleName;
	}
public static void main(String[] args) throws IOException {
	System.out.println(getVersionID());
}
public static  int getTcId(String testCaseName) throws IOException
	{
	    int testCaseID=0;
	    //Response response = doGetRequest("https://jira.tegile.com:8443/rest/zapi/latest/execution?projectId=10105&versionId=11602&cycleId=415&maxResults=-1");
		Response response = doGetRequest("https://jira.tegile.com:8443/rest/zapi/latest/execution?projectId="+getProject()+"&versionId="+getVersionID()+"&cycleId=414&maxResults=-1");
	    List<String> s=response.path("executions.issueKey");
	    List<Integer> b=response.path("executions.id");
	    for (int i = 0; i < s.size(); i++) {
		     if(s.get(i).equals(testCaseName))
		     {
		    	 
		    	 testCaseID= b.get(i);
		    	 
		     }
		}
		return testCaseID;		
	}
	

public static void updateTestCaseToWIP(String testCaseJiraId) throws IOException
{
	String k=Integer.toString(getTcId(testCaseJiraId));
	System.out.println(k);
    PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
    authScheme.setUserName(jiraUserName);
    authScheme.setPassword(jiraPassword);
    RestAssured.authentication = authScheme;
    String testCaseStatus=null;
    String url="https://jira.tegile.com:8443/rest/zapi/latest/execution/"+k+"/execute";
    Map<String, Object>  jsonAsMap = new HashMap<String, Object>();
    jsonAsMap.put("status", "3");
    given().
    contentType("application/json").
    body(jsonAsMap).
    when().
    put(url);
}
public static void updateTestCaseToPass(String testCaseJiraId,String testResult) throws IOException
{
	String k=Integer.toString(getTcId(testCaseJiraId));
	System.out.println(k);
    PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
    authScheme.setUserName(jiraUserName);
    authScheme.setPassword(jiraPassword);
    RestAssured.authentication = authScheme;
    String testCaseStatus=null;
    String url="https://jira.tegile.com:8443/rest/zapi/latest/execution/"+k+"/execute";
    Map<String, Object>  jsonAsMap = new HashMap<String, Object>();
        jsonAsMap.put("status", "1");
        given().
        contentType("application/json").
        body(jsonAsMap).
        when().
        put(url);
    
}

public static void updateTestCaseToFail(String testCaseJiraId,String testResult) throws IOException
{
	String k=Integer.toString(getTcId(testCaseJiraId));
	System.out.println(k);
    PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
    authScheme.setUserName(jiraUserName);
    authScheme.setPassword(jiraPassword);
    RestAssured.authentication = authScheme;
    String testCaseStatus=null;
    String url="https://jira.tegile.com:8443/rest/zapi/latest/execution/"+k+"/execute";
    Map<String, Object>  jsonAsMap = new HashMap<String, Object>();
        jsonAsMap.put("status", "2");
        given().
        contentType("application/json").
        body(jsonAsMap).
        when().
        put(url);
    
}





























	
}
