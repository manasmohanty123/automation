package com.tegile.intelliflash.testdriver;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.tegile.intelliflash.pageObject.facebookLogin;

public class facebookLoginPage  {

	
	WebDriver wd;
	facebookLogin flogin;
	@BeforeClass
	public void demo()
	{
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver_win32\\chromedriver.exe");
		  wd=new ChromeDriver();
		  flogin=PageFactory.initElements(wd, facebookLogin.class);
		
	}
	@Test
	public void testMethod()
	{
		wd.get("https://www.facebook.com");
		flogin.loginPage();
	}
	
	
	
	
}
