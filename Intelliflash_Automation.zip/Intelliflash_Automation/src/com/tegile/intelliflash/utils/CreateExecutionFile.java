package com.tegile.intelliflash.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;





public class CreateExecutionFile {

	/**
	 * @param args
	 * @throws ParserConfigurationException 
	 * @throws TransformerException 
	 * @throws IOException 
	 */
	public static  Properties propConfig=null;
	@BeforeTest
	public void createExecutionfile() throws IOException, ParserConfigurationException, TransformerException {
		///Properties propConfig=null;
		String propFilePath=System.getProperty("user.dir")+"\\src\\com\\tegile\\intelliflash\\configuration\\config.properties";
		propConfig=new Properties();
		FileInputStream fi=new FileInputStream(propFilePath); 
		propConfig.load(fi);
		
		//Deleting old suites
		File suiteFolder = new File(System.getProperty("user.dir")+"\\src\\com\\tegile\\intelliflash\\testsuites\\");
	    System.out.println("Deleting files");
	    if (suiteFolder.isDirectory()) {
	        for (File f : suiteFolder.listFiles()) 
	        {
	        	f.delete();
	        }
	        
	       
	        }
	   
//----------------------------------------------------------------
		Object[][] client_Executionstatus=getInputSheetData("TestDriverWorkBook", "Executable_Suites");
		
		
		Hashtable<String ,String> execution=new Hashtable<String,String>();
		
		for(int i=0;i<client_Executionstatus.length;i++)
		{
				execution.put(client_Executionstatus[i][0].toString(), client_Executionstatus[i][1].toString());	
		}
	//----------------------------------------------------------	
		String masterExcelLoc =propConfig.getProperty("TestWorkBooks");
        FileInputStream file = new FileInputStream(System.getProperty("user.dir")+masterExcelLoc+"TestDriverWorkBook"+".xlsx");
		
		XSSFWorkbook workbook = new XSSFWorkbook(file);
        
       int m=0;
       String sheetName="";
       List<String> clients=new ArrayList<String>();
       while(sheetName!=null)
       {
      	 try{
      	 sheetName=workbook.getSheetName(m++);
      	 if(sheetName.contains("Client")&& execution.get(sheetName).equalsIgnoreCase("Y"))
      			
      	 clients.add(sheetName);
      			 
      	 }
      	 catch(Exception e)
      	 {
      		 break;
      	 }
      	 //System.out.println(sheetName); 
       }
      
		boolean parallel=false;
     String parallelRun=  propConfig.getProperty("parallel");
     if(parallelRun.equalsIgnoreCase("Yes"))
    	 parallel=true;
    	 
		for(int x=0;x<clients.size();x++)
		{
		String clientSheet=clients.get(x);
		
		Object[][] masterSheetData=getInputSheetData("TestDriverWorkBook", clientSheet);
		List<String> TestCases=new ArrayList<String>();
		List<String> Browser=new ArrayList<String>();
		List<String> Version=new ArrayList<String>();
		for(int i=1;i<masterSheetData.length;i++)
		{
			if(masterSheetData[i][1]!=null)
			{
				if(masterSheetData[i][1].toString().length()!=0)
				{
					//System.out.println(masterSheetData[i][1].toString());
			TestCases.add(masterSheetData[i][1].toString());
			Browser.add(masterSheetData[i][12].toString());
			Version.add(masterSheetData[i][13].toString());
				}
			}
		}
			
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		
		Document doc = docBuilder.newDocument();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		
		Element rootElement = doc.createElement("suite");
		doc.appendChild(rootElement);
		
		Attr attr = doc.createAttribute("name");
		attr.setValue("TestCase_Suite_"+clientSheet);
		rootElement.setAttributeNode(attr);
		
		if(parallel)
		{
		Attr attr1 = doc.createAttribute("parallel");
		attr1.setValue("tests");
		rootElement.setAttributeNode(attr1);
		
		
		String threads=propConfig.getProperty("threadCount");
		
		Attr attr2 = doc.createAttribute("thread-count");
		attr2.setValue(threads);
		rootElement.setAttributeNode(attr2);
		}
		
		Element listeners = doc.createElement("listeners");
		rootElement.appendChild(listeners);
		
		Element listener = doc.createElement("listener");
		listeners.appendChild(listener);
		Attr listener_attr = doc.createAttribute("class-name");
		listener_attr.setValue("com.tegile.intelliflash.listeners.TestsListenerAdapter");
		listener.setAttributeNode(listener_attr);
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		
		Element param = doc.createElement("parameter");
		rootElement.appendChild(param);
		
		Attr param_attr = doc.createAttribute("name");
		param_attr.setValue("ClientSheet" );
		param.setAttributeNode(param_attr);
		
		Attr param_attr2 = doc.createAttribute("value");
		param_attr2.setValue(clientSheet);
		param.setAttributeNode(param_attr2);
		
		
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
	
		String browser="firefox";
		String version="20.0";
			
		for(int i=0;i<TestCases.size();i++)
		{
			browser="firefox";
			version="20.0";
			
				Element tests = doc.createElement("test");
				rootElement.appendChild(tests);
				
				Attr tests_attr = doc.createAttribute("name");
				tests_attr.setValue("Test_"+TestCases.get(i).toString());
				tests.setAttributeNode(tests_attr);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				//----------------------------
				param = doc.createElement("parameter");
				tests.appendChild(param);
				
				param_attr = doc.createAttribute("name");
				param_attr.setValue("TestCase" );
				param.setAttributeNode(param_attr);
				
				param_attr2 = doc.createAttribute("value");
				param_attr2.setValue(TestCases.get(i).toString() );
				param.setAttributeNode(param_attr2);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				
				param = doc.createElement("parameter");
				tests.appendChild(param);
				
				param_attr = doc.createAttribute("name");
				param_attr.setValue("browser" );
				param.setAttributeNode(param_attr);
				
				if(!Browser.get(i).toString().equalsIgnoreCase("")&&Browser.get(i).toString()!=null)
				browser=Browser.get(i).toString();
				
				param_attr2 = doc.createAttribute("value");
				param_attr2.setValue(browser);
				param.setAttributeNode(param_attr2);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				
				param = doc.createElement("parameter");
				tests.appendChild(param);
				
				param_attr = doc.createAttribute("name");
				param_attr.setValue("version" );
				param.setAttributeNode(param_attr);
				
				if(!Version.get(i).toString().equalsIgnoreCase("")&&Version.get(i).toString()!=null)
				version=Version.get(i).toString();
				
				param_attr2 = doc.createAttribute("value");
				param_attr2.setValue(version);
				param.setAttributeNode(param_attr2);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				
				
				param = doc.createElement("parameter");
				tests.appendChild(param);
				
				param_attr = doc.createAttribute("name");
				param_attr.setValue("platform" );
				param.setAttributeNode(param_attr);
				
				param_attr2 = doc.createAttribute("value");
				param_attr2.setValue("WINDOWS");
				param.setAttributeNode(param_attr2);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				//-----------------------------------
				
				Element classes = doc.createElement("classes");
				tests.appendChild(classes);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
				//-------------------------
				
				Element classe = doc.createElement("class");
				classes.appendChild(classe);
				
				Attr classe_attr = doc.createAttribute("name");
				classe_attr.setValue("com.tegile.intelliflash.testdriver.TestCaseDriver");
				classe.setAttributeNode(classe_attr);
				transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		}

			
		
					
		// write the content into xml file
		DOMSource source = new DOMSource(doc);
		
		StreamResult result = new StreamResult(new File(System.getProperty("user.dir")+"\\src\\com\\tegile\\intelliflash\\testsuites\\"+clientSheet+".xml"));
		
		transformer.transform(source, result);
 
		System.out.println("Execution file for "+clientSheet+" created!");

	}

		
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		
		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
		
		Document doc = docBuilder.newDocument();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		Element rootElement = doc.createElement("suite");
		doc.appendChild(rootElement);
		Attr attr = doc.createAttribute("name");
		attr.setValue("MasterSuite");
		rootElement.setAttributeNode(attr);
		
		Element listeners = doc.createElement("listeners");
		rootElement.appendChild(listeners);
		
		Element listener = doc.createElement("listener");
		listeners.appendChild(listener);
		Attr listener_attr = doc.createAttribute("class-name");
		listener_attr.setValue("com.tegile.intelliflash.listeners.TestsListenerAdapter");
		listener.setAttributeNode(listener_attr);
	
		
		Element msuite = doc.createElement("suite-files");
		rootElement.appendChild(msuite);
		
	
		
		for(int k=0;k<clients.size();k++)
		{
		Element suite = doc.createElement("suite-file");
		msuite.appendChild(suite);
		
		Attr suite_path = doc.createAttribute("path");
		boolean console=true;
		 for (File f : suiteFolder.listFiles()) 
	        {
	        	if(f.getName().contains("%"))
	        	console=false;
	        }
		String nclientSheet=clients.get(k).toString();
		if(!console)
		nclientSheet=clients.get(k).toString().replace(" ", "%20");
		
		suite_path.setValue("src\\com\\tegile\\intelliflash\\testsuites\\"+nclientSheet+".xml");
		suite.setAttributeNode(suite_path);
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		}
	
		
		// write the content into xml file
		DOMSource source = new DOMSource(doc);
		StreamResult result = new StreamResult(new File(System.getProperty("user.dir")+"\\src\\com\\tegile\\intelliflash\\testsuites\\"+"MastersuiteExecuter"+".xml"));

		transformer.transform(source, result);
 
		System.out.println("Master Execution file created!");
		
	}
	
	  public static Object[][] getInputSheetData(String workbookName,String testData_inputSheetName) throws IOException
      {
   	String workBook =propConfig.getProperty("TestWorkBooks");
         FileInputStream file = new FileInputStream(System.getProperty("user.dir")+workBook+workbookName+".xlsx");
             XSSFWorkbook workbook = new XSSFWorkbook(file);
             
             XSSFSheet sheet = workbook.getSheet(testData_inputSheetName);
             
             Iterator<Row> rowIterator = sheet.iterator();
             int rowcount=0;
             
            Row Sample_row=null;
             while (rowIterator.hasNext()) {
                    rowcount++;
                    rowIterator.next();
                   }
             
             
             rowIterator = sheet.iterator();
             Sample_row=rowIterator.next();
             Iterator<Cell> cellIterator=Sample_row.iterator();
             int cellCount=0;
             
             
             while (cellIterator.hasNext()) {
           	  cellCount++;
                    cellIterator.next();
                    
             } 
              
             Object[][] ob=new Object[rowcount][cellCount]; 
             
             
             rowIterator = sheet.iterator();
             int i=-1;
             int j=-1;
             
             while (rowIterator.hasNext()) {
                    i++;
                    //System.out.println("Row="+(i+1));
                    Row row = rowIterator.next();
                    cellIterator=Sample_row.iterator();
                    j=-1;
                   while(++j<cellCount) 
                    {
                   	//System.out.print((j+1)+"=");
                   	if(row.getCell(j)==null)
                   	{
                   		//System.out.println("It is null");
                   		ob[i][j] ="";		
                   	}
                   	
                   	else
                   	{
                   	ob[i][j] = row.getCell(j).toString();
                   	//System.out.print(row.getCell(j).toString());
                   	}
                   	
                    }
                   //System.out.println();
             }

				return ob;
  
      }
}