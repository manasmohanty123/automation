package com.tegile.intelliflash.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;

import com.tegile.intelliflash.init.Init;
import com.tegile.intelliflash.listeners.ErrorUtils;
import com.tegile.intelliflash.testdriver.TestCaseDriver;



public class JavaLib {
	
	
	//Log the information
	public static void log(String message)
	{
			
		Init.APP_LOGS.debug(message);
	}
	
	
	//Compares 2 string values
	public static void AssertEquals(WebDriver wd,String strActual, String strExpected,String message){
		try{
			Assert.assertEquals(strActual, strExpected,message);
		}catch(Throwable th){
			
			String exception="Expected=\""+strExpected+"\", but found=\""+strActual+"\"" ;
		ErrorUtils.addVerificationFailure(exception,wd,th);
		}
		}
	
	//compares 2 boolean values
	public static void AssertBooleanEquals(WebDriver wd,boolean blnActual, boolean blnExpected,String message){
		try{
			Assert.assertEquals(blnActual, blnExpected,message);
		}catch(Throwable th){
			ErrorUtils.addVerificationFailure(message,wd,th);
		}
}

	

       public static String[] splitToArray(String inputValue)
        {
	      String[] inputArray=inputValue.split("~|:");
	      return inputArray;
        }
	 
	 
	    public static Object[][] getInputSheetData(String workbookName,String testData_inputSheetName) throws IOException
	       {
	    	String workBook =Init.propConfig.getProperty("TestWorkBooks");
              FileInputStream file = new FileInputStream(System.getProperty("user.dir")+workBook+workbookName+".xlsx");
	              XSSFWorkbook workbook = new XSSFWorkbook(file);
	              
	              XSSFSheet sheet = workbook.getSheet(testData_inputSheetName);
	              
	              Iterator<Row> rowIterator = sheet.iterator();
	              int rowcount=0;
	              
	             Row Sample_row=null;
	              while (rowIterator.hasNext()) {
	                     rowcount++;
	                     rowIterator.next();
	                    }
	              
	              
	              rowIterator = sheet.iterator();
	              Sample_row=rowIterator.next();
	              Iterator<Cell> cellIterator=Sample_row.iterator();
	              int cellCount=0;
	              
	              
	              while (cellIterator.hasNext()) {
	            	  cellCount++;
	                     cellIterator.next();
	                     
	              } 
	               
	              Object[][] ob=new Object[rowcount][cellCount]; 
	              
	              
	              rowIterator = sheet.iterator();
	              int i=-1;
	              int j=-1;
	              
	              while (rowIterator.hasNext()) {
	                     i++;
	                     //System.out.println("Row="+(i+1));
	                     Row row = rowIterator.next();
	                     cellIterator=Sample_row.iterator();
	                     j=-1;
	                    while(++j<cellCount) 
	                     {
	                    	//System.out.print((j+1)+"=");
	                    	if(row.getCell(j)==null)
	                    	{
	                    		//System.out.println("It is null");
	                    		ob[i][j] ="";		
	                    	}
	                    	
	                    	else
	                    	{
	                    	ob[i][j] = row.getCell(j).toString();
	                    	//System.out.print(row.getCell(j).toString());
	                    	}
	                    	
	                     }
	                    //System.out.println();
	              }

					return ob;
       
	       }

	    public static void zipReportFolder() throws Exception
		{
	    	
	    	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			   //get current date time with Date()
			   Date date = new Date();
			   String eDate=dateFormat.format(date).replace('/', '_').replace(':', '_');
			  System.out.println(eDate);
			  zipDir(System.getProperty("user.dir")+"\\test-output",System.getProperty("user.dir")+"\\ExecutionReports\\"+eDate+"_TestNGReport.zip");
			  zipDir(System.getProperty("user.dir")+"\\ReportFiles",System.getProperty("user.dir")+"\\ExecutionReports\\"+eDate+"_XSLTReport.zip");
			  zipDir(System.getProperty("user.dir")+"\\Sel_HTML_Reports",System.getProperty("user.dir")+"\\ExecutionReports\\"+eDate+"_SelHTMLReport.zip");
		}


	  static private void zipDir(String srcFolder, String destZipFile) throws Exception {
	    ZipOutputStream zip = null;
	    FileOutputStream fileWriter = null;

	    fileWriter = new FileOutputStream(destZipFile);
	    zip = new ZipOutputStream(fileWriter);

	    addFolderToZip("", srcFolder, zip);
	    zip.flush();
	    zip.close();
	  }

	  static private void addFileToZip(String path, String srcFile, ZipOutputStream zip)
	      throws Exception {

	    File folder = new File(srcFile);
	    if (folder.isDirectory()) {
	      addFolderToZip(path, srcFile, zip);
	    } else {
	      byte[] buf = new byte[1024];
	      int len;
	      FileInputStream in = new FileInputStream(srcFile);
	      zip.putNextEntry(new ZipEntry(path + "/" + folder.getName()));
	      while ((len = in.read(buf)) > 0) {
	        zip.write(buf, 0, len);
	      }
	    }
	  }

	  static private void addFolderToZip(String path, String srcFolder, ZipOutputStream zip)
	      throws Exception {
	    File folder = new File(srcFolder);

	    for (String fileName : folder.list()) {
	      if (path.equals("")) {
	        addFileToZip(folder.getName(), srcFolder + "/" + fileName, zip);
	      } else {
	        addFileToZip(path + "/" + folder.getName(), srcFolder + "/" + fileName, zip);
	      }
	    }
	  }
	  
	 public static void addToReport(boolean skip,StringBuilder sb,String TC,String stepDescription,String result,String error,String scrnShot)
	 {
		 if(skip){
			 sb.append("<tr><td>"+TC+"</td><td>"+stepDescription+"</td><td BGCOLOR=\"YELLOW\">"+result+"</td><td>"+error+"</td><td></td></tr>"); 
			
		 }
		 else
			 {
			 if(error.equals("-"))
			 {
				 if(scrnShot.equals("-"))
					 sb.append("<tr><td>"+TC+"</td><td>"+stepDescription+"</td><td BGCOLOR=\"GREEN\">"+result+"</td><td>"+error+"</td><td>"+scrnShot+"</td></tr>");	 
				 else
					 sb.append("<tr><td>"+TC+"</td><td>"+stepDescription+"</td><td BGCOLOR=\"GREEN\">"+result+"</td><td>"+error+"</td><td><a href="+scrnShot+".jpeg "+"target=\"_blank\">Click</a></td></tr>");
		
			 }
			else
		 {
			// error="Unable to locate element:";
			 sb.append("<tr><td>"+TC+"</td><td>"+stepDescription+"</td><td BGCOLOR=\"RED\">"+result+"</td><td>"+error+"</td><td><a href="+scrnShot+".jpeg "+"target=\"_blank\">Click</a></td></tr>");
		 } 
			 }
	 }

}
