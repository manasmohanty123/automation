package com.tegile.intelliflash.init;

import java.io.IOException;
import java.io.InputStream;
import java.security.Security;

import org.bouncycastle.jce.provider.BouncyCastleProvider;


import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

public class Execute_SSH {

	public  static String  RunSSH_command(String command,String password) throws JSchException, IOException
	{  
		
		 String user=Init.propConfig.getProperty("ssh_userName");
		 String host=Init.propConfig.getProperty("ssh_IpAdress");
		 String pwd=Init.propConfig.getProperty("ssh_password");
        try{

		String response=null;
		Session session = new JSch().getSession(user, host, 22);		
		session.setPassword(password);
		//Log.info(password+"Entered");
		java.util.Properties config = new java.util.Properties(); 
		Security.insertProviderAt(new BouncyCastleProvider(),1);
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);
		session.connect();
		//Log.info("Sesson connected succesfully");
		Channel channel=session.openChannel("exec");
		((ChannelExec)channel).setCommand(command);
		channel.setInputStream(null);
		((ChannelExec)channel).setErrStream(System.err);
		InputStream in=channel.getInputStream();
		channel.connect();
		
		
	      byte[] tmp=new byte[1024];
	      while(true){
	        while(in.available()>0){
	          int i=in.read(tmp, 0, 1024);
	          if(i<0)break;
	           response=new String(tmp, 0, i);
	           
	           
	        }
	        if(channel.isClosed()){
	          if(in.available()>0) continue; 
	        
	          break;
	        }
	        try{Thread.sleep(1000);}catch(Exception ee){}
	      }
	      channel.disconnect();
	      session.disconnect();
	     
		return response;
        }
        catch(Exception e)
        {   e.printStackTrace();
        	
        	return null;
        }

	}
	
	public  static String  RunSSH_commandWithIP(String command,String hostname) throws JSchException, IOException
	{
		 String user=Init.propConfig.getProperty("ssh_userName");
		 String host=Init.propConfig.getProperty("ssh_IpAdress");
		 String pwd=Init.propConfig.getProperty("ssh_password");
        try{
		String response=null;
		Session session = new JSch().getSession(user, hostname, 22);		
		session.setPassword(pwd);
		//Log.info(password+"Entered");
		java.util.Properties config = new java.util.Properties(); 
		Security.insertProviderAt(new BouncyCastleProvider(),1);
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);
		session.connect();
		Channel channel=session.openChannel("exec");
		((ChannelExec)channel).setCommand(command);
		channel.setInputStream(null);
		((ChannelExec)channel).setErrStream(System.err);
		InputStream in=channel.getInputStream();
		channel.connect();
		
		
	      byte[] tmp=new byte[1024];
	      while(true){
	        while(in.available()>0){
	          int i=in.read(tmp, 0, 1024);
	          if(i<0)break;
	           response=new String(tmp, 0, i);
	           
	           
	        }
	        if(channel.isClosed()){
	          if(in.available()>0) continue; 
	        
	          break;
	        }
	        try{Thread.sleep(1000);}catch(Exception ee){}
	      }
	      channel.disconnect();
	      session.disconnect();
	     
		return response;
        }
        catch(Exception e)
        {   e.printStackTrace();
        	return null;
        }

	}
	public  static String  RunSSH_commandVcenter(String command,String host) throws JSchException, IOException
	{   
		
		 String user="root";
		 String pwd="Tegile123!";
        try{

		String response=null;
		Session session = new JSch().getSession(user, host, 22);		
		session.setPassword(pwd);
		//Log.info(password+"Entered");
		java.util.Properties config = new java.util.Properties(); 
		Security.insertProviderAt(new BouncyCastleProvider(),1);
		config.put("StrictHostKeyChecking", "no");
		session.setConfig(config);
		session.connect();
		//Log.info("Sesson connected succesfully");
		Channel channel=session.openChannel("exec");
		((ChannelExec)channel).setCommand(command);
		channel.setInputStream(null);
		((ChannelExec)channel).setErrStream(System.err);
		InputStream in=channel.getInputStream();
		channel.connect();
		
		
	      byte[] tmp=new byte[1024];
	      while(true){
	        while(in.available()>0){
	          int i=in.read(tmp, 0, 1024);
	          if(i<0)break;
	           response=new String(tmp, 0, i);
	           
	           
	        }
	        if(channel.isClosed()){
	          if(in.available()>0) continue; 
	        
	          break;
	        }
	        try{Thread.sleep(1000);}catch(Exception ee){}
	      }
	      channel.disconnect();
	      session.disconnect();
	     
		return response;
        }
        catch(Exception e)
        {   e.printStackTrace();
        	return null;
        }

	}
	

	public static void main(String[] args) throws IOException, JSchException {
		//System.out.println(RunSSH_commandWithIpAndPassword("service-control --stop vsphere-client", "10.67.13.32", "administrator@vsphere.local", "Tegile123!"));
	//System.out.println(RunSSH_commandWithIpAndPassword("date", "10.67.1.133", "admin", "t"));
		System.out.println(RunSSH_commandVcenter("service-control --start vsphere-client","10.67.13.32"));
	
	}
}
