package com.tegile.intelliflash.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.tegile.intelliflash.utils.JavaLib;

public class Page_BenefitElections {
	
public static List<String> benefitelections=new ArrayList<String>();
public static HashMap<String,String> hmBenefitElection=new HashMap<String,String>();
	
	public static void getbenefitelections(WebDriver wd)
	{
		
		benefitelections.add("FirstName~.//*[@id='ctl00_PageContent_txtFirstName']~value");
		benefitelections.add("MiddleName~.//*[@id='ctl00_PageContent_txtMiddleName']~value");
		benefitelections.add("LastName~.//*[@id='ctl00_PageContent_txtLastName']~value");
		benefitelections.add("Suffix~.//*[@id='ctl00_PageContent_cmbSuffix']~drpdwn");
		benefitelections.add("DOB~.//*[@id='ctl00_PageContent_txtDOB']~value");
		benefitelections.add("SSN~.//*[@id='ctl00_PageContent_txtSSN']~value");
		benefitelections.add("DateOfHire~.//*[@id='ctl00_PageContent_DateOfHire']~value");
		benefitelections.add("Status~.//*[@id='ctl00_PageContent_cmbStatus']~drpdwn");
		benefitelections.add("PCP~.//*[@id='ctl00_PageContent_txtPCP']~value");
		benefitelections.add("StreetAddress1~.//*[@id='ctl00_PageContent_txtAddressLine1']~value");
		benefitelections.add("StreetAddress2~.//*[@id='ctl00_PageContent_txtAddressLine2']~value");
		benefitelections.add("Zip~.//*[@id='ctl00_PageContent_txtZipCode']~value");
		benefitelections.add("County~.//*[@id='ctl00_PageContent_cmbCounty']~value");
		benefitelections.add("PhoneNo~.//*[@id='ctl00_PageContent_txtMainPhone']~value");
		benefitelections.add("Extension~.//*[@id='ctl00_PageContent_txtPhoneExtension']~value");
		benefitelections.add("Email~.//*[@id='ctl00_PageContent_txtEmail']~value");

		

		
		
		Select sel=null;
		for(int i=0;i<benefitelections.size();i++)
		{
			String info=benefitelections.get(i);
			String[] data=info.split("~");
			if(!data[2].equalsIgnoreCase("drpdwn"))
				hmBenefitElection.put(data[0], wd.findElement(By.xpath(data[1])).getAttribute(data[2]));
			else
			{
				sel=new Select(wd.findElement(By.xpath(data[1])));
				hmBenefitElection.put(data[0], sel.getFirstSelectedOption().getText());
			}
				
			
		}
		
		for(int i=0;i<benefitelections.size();i++)
		{
			String info=benefitelections.get(i);
			String[] data=info.split("~");
			String censusData1=Page_CensusDetails.hmCensusDetails.get(data[0]);
			String censusData2=Page_BenefitElections.hmBenefitElection.get(data[0]);
			System.out.println(censusData1+"="+censusData2);
			
			JavaLib.AssertEquals(wd, censusData2, censusData1, "Not matching");
		}
		
		
	}


}
