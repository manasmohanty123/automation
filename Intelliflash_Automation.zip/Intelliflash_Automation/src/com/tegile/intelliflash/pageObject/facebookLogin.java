package com.tegile.intelliflash.pageObject;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class facebookLogin {

		
	@FindBy(xpath="//input[@id='email']")
	private WebElement userName;
	@FindBy(xpath="//input[@id='pass']")
	private WebElement password;
	@FindBy(xpath="//input[@value='Log In']")
	private WebElement loginBtn;
	
	
	public void loginPage()
	{
		userName.sendKeys("manas");
		password.sendKeys("password");
		loginBtn.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
