package com.tegile.intelliflash.pages;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.tegile.intelliflash.utils.SelLib;

public class Page_EligibilityInformation {
	
	
	public static void selectDateFromCalender(WebDriver wd,String locator,String date) throws InterruptedException
	{
		
		
		
		Thread.sleep(2000);
		SelLib.clickOnElement(wd, locator);
		Thread.sleep(3000);
		
	
		String[] dates=date.split("/");
		SelLib.selectOptionbyValue(wd, "xpath~.//*[@id='ui-datepicker-div']/div/div/select[2]~Element Not found",dates[2]);
		Thread.sleep(2000);
		SelLib.selectOptionbyValue(wd, "xpath~.//*[@id='ui-datepicker-div']/div/div/select[2]~Element Not found",dates[2]);
		Thread.sleep(2000);
		SelLib.selectOptionbyValue(wd, "xpath~.//*[@id='ui-datepicker-div']/div/div/select[1]~Element Not found",String.valueOf((Integer.parseInt(dates[0])-1)));
		Thread.sleep(3000);
		SelLib.selectOptionbyValue(wd, "xpath~.//*[@id='ui-datepicker-div']/div/div/select[2]~Element Not found",dates[2]);
		Thread.sleep(2000);
		if(!(dates[1].length()==1) && Integer.parseInt(dates[1].substring(0, 1))==0)
			dates[1]=dates[1].substring(1);
		wd.findElement(By.xpath(".//*[@id='ui-datepicker-div']/table/tbody/tr/td/a[text()='"+dates[1]+"']")).click();
		Thread.sleep(2000);
	}

}
