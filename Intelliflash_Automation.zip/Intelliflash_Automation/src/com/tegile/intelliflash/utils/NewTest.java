package com.tegile.intelliflash.utils;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class NewTest {
 
	public static void main(String[] args) {
		String s1="xpath~//input[@id='email']://input[@id='pass']://label[@id='loginbutton']~Element not found";
		String s2="manasmohanty:welcome1234";
		String[]s1Array = s1.split("~|:");
		for (int i = 0; i < s1Array.length; i++) {
			System.out.println(s1Array[i]);
		}
		
		
	}

}
