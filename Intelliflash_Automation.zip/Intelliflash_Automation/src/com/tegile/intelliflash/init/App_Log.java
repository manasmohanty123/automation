package com.tegile.intelliflash.init;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class App_Log {

	
	
	static{
		if (System.getProperty("os.name").contains("mac")){
	 PropertyConfigurator.configure(System.getProperty("user.dir")+"\\src\\log4j.properties");
	 }else{
		PropertyConfigurator.configure(System.getProperty("user.dir")+"\\src\\log4j.properties");
	 }
		}
	
	public static Logger log=Logger.getLogger(Logger.class);

public static void startTestCase(String sTestCaseName){

	

	log.info("****************************************************************************************");

	log.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");

	log.info("****************************************************************************************");


	}

	
public static void endTestCase(String sTestCaseName){

	log.info("****************************************************************************************");

	log.info("XXXXXXXXXXXXXXXXXXXXXXX "+  sTestCaseName     + "  "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");

	log.info("*************************"+  sTestCaseName     + "  "+"-P---A---S---S"+"  ****************************");
	}


public static void info(String message) {

		log.info(message);

		}

public static void warn(String message) {

   log.warn(message);

	}

public static void error(String message) {

   log.error(message);

	}

public static void fatal(String message) {

   log.fatal(message);

	}

public static void debug(String message) {

   log.debug(message);

	}


public static void endTestCaseWithoutExecutionResult(String sTestCaseName){

	log.info("****************************************************************************************");

	log.info("XXXXXXXXXXXXXXXXXXXXXXX "+  sTestCaseName     + "  "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");

	}


}
