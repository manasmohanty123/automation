package com.tegile.intelliflash.utils;

import java.awt.AWTException;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.Reporter;

import com.tegile.intelliflash.init.Init;
import com.tegile.intelliflash.init.Init_WebDriver;
import com.tegile.intelliflash.listeners.ErrorUtils;
import com.tegile.intelliflash.pages.Page_BenefitElections;
import com.tegile.intelliflash.pages.Page_CensusDetails;
import com.tegile.intelliflash.pages.Page_EligibilityInformation;
import com.tegile.intelliflash.pages.Page_EmployeeInformation;
import com.tegile.intelliflash.testdriver.TestCaseDriver;



public class SelLib {
	
	//static 
	
	
	public static int subscriber_DOB=1975;
	public static int dependent1_DOB=1980;
	public static int dependent2_DOB=2005;
	public static int dependent3_DOB=2009;
			
	public static String[][] rates;
	
	public static double  totalRate=0;
	
	
	public static String exception="";
	public static String prospectCompany;
	
	public static void openPage(WebDriver wd,String url)
	{
		try{
			
			wd.get(url);
	//String e1= wd.findElement(By.xpath(".//*[@id='lblLog']")).getText();
			
			Init.executionEnv=wd.getCurrentUrl();
			String data[]=Init.executionEnv.split("/");
			Init.executionEnv="";
			for(int i=0;i<data.length-1;i++)
			Init.executionEnv="QA";
			Init.executionbuildVersion="test";
			
			
		}
		catch(Throwable t)
		{
			
			exception="Failed to open the page";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}
	
	
	//Navigate to
	public static void navigateTo(WebDriver wd,String url)
	{
		try{
			
			wd.navigate().to(url);
			}
			catch(Throwable t)
			{
				exception="Failed to navigate";
				ErrorUtils.addVerificationFailure(exception,wd,t);
				
			}
	}
	
	//Returns page title
	public static String getPagetitle(WebDriver wd)
		{
		
		try{
			return wd.getTitle();
		}
		
		catch(Throwable t)
		{
			exception="Failed to read the title";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
		return null;
		}
	
	//Close the opened page
	public static void closePage(WebDriver wd)
	{	
		try{
		wd.close();
		}
		
		catch(Throwable t)
		{
			exception="Failed to close the page";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}
	
	//Close the application
	public static void closeApplication(WebDriver wd)
	{
		try{
		wd.quit();
		}
		catch(Throwable t)
		{
			exception="Failed to close the application";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}

	//Click on an element
	public static void clickOnElement(WebDriver wd,String locator)
	{
		
		try{
		  getElement(wd,locator).click();
			
		}
		catch(Throwable t)
		{
			exception="Failed to click on the element";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
	}
	
	//Read elements displayed text 
	public static String getElementText(WebDriver wd,String locator)
	{
		try{
			return getElement(wd,locator).getText();
		}
		catch(Throwable t)
		{
			exception="Failed to read the attached text";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return null;
		}
	}
	
	//Enter text in to the text input field
	public static void enterText(WebDriver wd,String locator,String input,String uniqueInput)
	{
		try{
			if(input !=null)
			getElement(wd,locator).sendKeys(input);
		}
		catch(Throwable t)
		{
			exception="Failed to enter the text";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}	
	}
	
	public static void clearText(WebDriver wd,String locator)
	{
		try{
			getElement(wd, locator).clear();
		}
		catch(Throwable t)
		{
			exception="Failed to delete the text";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}	
	}
	
	//Returns element's attribute value
	public static String getElementProperty(WebDriver wd,String locator,String attribute)
	{
		try{
			return getElement(wd,locator).getAttribute(attribute);
		}
		catch(Throwable t)
		{
			exception="Failed to get the element property value";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return null;
		}
	}
	
	//Select option from drop down box by option index
	public static void selectOptionbyIndex(WebDriver wd,String locator,int index)
	{
		try{
			Select sel=new Select(getElement(wd,locator));
			sel.selectByIndex(index);
		}
		catch(Throwable t)
		{
			exception="Failed to select";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}	
	}
	
	//Select option from drop down box by option value
	public static void selectOptionbyValue(WebDriver wd,String locator,String value)
	{
		try{
			Select sel=new Select(getElement(wd,locator));
			sel.selectByValue(value);
			
		}
		catch(Throwable t)
		{
			exception="Failed to select";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
	}
	
	//Select option from drop down box by option text
	public static void selectOptionbyText(WebDriver wd,String locator,String visibleText)
	{
		try{
			Select sel=new Select(getElement(wd,locator));
			sel.selectByVisibleText(visibleText);
		}
		catch(Throwable t)
		{
			exception="Failed to select";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	//Search for an element on the page
	public static boolean searchElement(WebDriver wd,String locator)
		{ 
			try{
				
			return getElement(wd,locator).isDisplayed();
			}
			catch(Throwable t)
			{
				exception="element is not displayed";
				ErrorUtils.addVerificationFailure(exception,wd,t);
				return false;
			}
			
		}
		
	//Check whether the element is active or not
	public static boolean isActive(WebDriver wd,String locator)
		{
			
			try
			{
				return getElement(wd,locator).isEnabled();
			}
			catch(Throwable t)
			{
				exception="element is not active";
				ErrorUtils.addVerificationFailure(exception,wd,t);
				return false;
			}
			
			
		}
		
	//Switch to a frame by frame name.
	public static void switchToFramebyName(WebDriver wd,String frameName)
		{
			try{
				wd.switchTo().frame(frameName);
			}
			catch(Throwable t)
			{
				exception="Faile to switch to frame";
				ErrorUtils.addVerificationFailure(exception,wd,t);
			}
		}
		
	//Switch to a frame by frame id
	public static void switchToFramebyId(WebDriver wd,String frameId)
		{
			try{
				wd.switchTo().frame(frameId);
			}
			catch(Throwable t)
			{
				exception="Faile to switch to frame";
				ErrorUtils.addVerificationFailure(exception,wd,t);
			}
		}

	//Switch to a frame by frame index
	public static void switchToFramebyIndex(WebDriver wd,int frameIndex)
		{
			try{
				wd.switchTo().frame(frameIndex);
			}
			catch(Throwable t)
			{
				exception="Faile to switch to frame";
				ErrorUtils.addVerificationFailure(exception,wd,t);
			}
		}	
	
	//Switch to the last child window
	public static void switchTolastChildWindow(WebDriver wd)
		{
		try{
			System.out.println("TotalWindows="+wd.getWindowHandles().size());
			for(String winHandle : wd.getWindowHandles())
			{
				wd.switchTo().window(winHandle);
			}
		}
		catch(Throwable t)
		{
			exception="Faile to switch to last window";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
		}
		
	//Switch to the nth child window
	public static void switchTonthChildWindow(WebDriver wd,int n)
				{
		System.out.println(wd.getWindowHandles().size());
		try{
					int i=0;
					for(String winHandle : wd.getWindowHandles())
					{
						i=i+1;
						if(n!=i)
							continue;
						{
						wd.switchTo().window(winHandle);
						break;
						}
					}
		}
		catch(Throwable t)
		{
			exception="Failed switch to nth Window";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
				}
		
	//Switch to parent window
	public static void switchToParentWindow(WebDriver wd)
		{
		try{
			Set<String> windows=  wd.getWindowHandles();
			Iterator<String> i=windows.iterator();
			wd.close();
			wd.switchTo().window(i.next());
			//wd.navigate().refresh();
		}
		catch(Throwable t)
		{
			exception="Failed switch to parent Window";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
		}
	
	public static void switchToDefaultWindow(WebDriver wd)
	{
	try{
		wd.switchTo().defaultContent();
	}
	catch(Throwable t)
	{
		exception="Failed switch to default Window";
		ErrorUtils.addVerificationFailure(exception,wd,t);
		
	}
	}
	
	//Returns the element irrespective of the passed locator data(Xpath,CSS,ID)
	public static WebElement getElement(WebDriver wd,String locatorData)
		{



			String temp[]=locatorData.split("~");
			String locateBy=temp[0];
			String locator=temp[1];
			String failureMessage=temp[2];
			
			try{
				
			if(locateBy.equalsIgnoreCase("XPATH"))
			{
				
			WebElement el=wd.findElement(By.xpath(locator));
			return el;
			}
			
			else if(locateBy.equalsIgnoreCase("CSS"))
			{
				return wd.findElement(By.cssSelector(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("ID"))
			{
				return wd.findElement(By.id(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("name"))
			{
				return wd.findElement(By.name(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("classname"))
			{
				return wd.findElement(By.className(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("linktext"))
			{
				return wd.findElement(By.linkText(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("partialtext"))
			{
				return wd.findElement(By.partialLinkText(locator));
			}
			
			else if(locateBy.equalsIgnoreCase("tagname"))
			{
				return wd.findElement(By.tagName(locator));
			}
			else return null;
			
			}
		
			
			catch(Throwable t)
			{
				
				System.out.println(t.getMessage());
				exception=failureMessage;
				ErrorUtils.addVerificationFailure(exception,wd,t);
				
				return null;
			}
			
			

		}//Takes screenshot
	public static void takeScreenshot(WebDriver wd,String fileName) throws InterruptedException {
		Thread.sleep(2000);
			File scrFile = ((TakesScreenshot)wd).getScreenshotAs(OutputType.FILE);
			Thread.sleep(1000);
			   try {
			FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\Sel_HTML_Reports\\"+fileName+".jpeg"));
			} 
			   catch (IOException e) {
			e.printStackTrace();
			}
		}
	
	//Handle alert popup
	
	public static void handleAlert(WebDriver wd,String response)
	{
	try{
		Alert al=wd.switchTo().alert();
		if(response.equalsIgnoreCase("accept"))
		{
			al.accept();
			wd.switchTo().defaultContent();
		
		}
		else
		{
			al.dismiss();
			wd.switchTo().defaultContent();
		}}
		
		catch(Throwable t)
		{
			exception="Failed to handle the alert";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}
	
	//verify alert popup error msg
	public static void verifyAlertMsg(WebDriver wd,String expectedmsg)
	{
		String actualMsg="";
		try
		{
			Alert al=wd.switchTo().alert();
		    actualMsg=al.getText();
		    Assert.assertEquals(actualMsg, expectedmsg);
		   // JavaLib.AssertEquals(wd, actualMsg, "");

		    }
		    
		
		catch(Throwable t)
		{
			exception="alertmsg showing "+actualMsg+" ,but expected "+expectedmsg;
			ErrorUtils.addVerificationFailure(exception,wd,t);
		}
	}
	
	
	public static void validatecheckPoint(WebDriver wd,String element,String validation,String expectation )
	{
		String actual="";
	
		try{
		if(validation.equalsIgnoreCase("presence"))
		{
			SelLib.searchElement(wd,element);
			
		}
			else if(validation.equalsIgnoreCase("text"))
			{
			actual= SelLib.getElementText(wd,element);
			JavaLib.AssertEquals(wd,actual,expectation,  "");
			
			
			}
			else if(validation.equalsIgnoreCase("partialtext"))
					{
				actual= SelLib.getElementText(wd,element);
				Assert.assertTrue(actual.contains(expectation));
				
					}
			else if(validation.equalsIgnoreCase("attribute"))
			{
		actual= SelLib.getElementProperty(wd,element,"value");
		Assert.assertTrue(actual.equals(expectation));
		
			}
		
			else if(validation.equalsIgnoreCase("DropDown"))
			{

				Select sel=new Select(SelLib.getElement(wd, element));
				String actR=sel.getFirstSelectedOption().getText();
				
				JavaLib.AssertEquals(wd, actR, expectation, "Expected  option is not selected ");
			}
	}
	catch(Throwable t)
	{
		exception="Expected="+expectation+",but found"+actual ;
		ErrorUtils.addVerificationFailure(exception,wd,t);
		return;
	}
		

		
			
		
	}
	
	public static void doubleClick(WebDriver wd,String locator)
	{
		try{
			
			Actions act=new Actions(wd);
			act.doubleClick(getElement(wd,locator));
			act.build().perform();
			
		}
		catch(Throwable t)
		{
			exception="Failed to double click";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	public static void selectSuggestion(WebDriver wd,String locator)
	{
		try{
			
			getElement(wd, locator).sendKeys(Keys.ARROW_DOWN);
			getElement(wd, locator).sendKeys(Keys.ENTER);
			
			
		}
		catch(Throwable t)
		{
			exception="Failed to double click";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	public static void clickonMyProfile(WebDriver wd,String locator)
	{
		wd.findElement(By.name("UserProfile")).click();
		int i=0;
		try{
			while(!wd.findElement(By.xpath("//input[starts-with(@id,'ctl00_PageContent_rptrEmpDependents_ct')]")).isDisplayed())
			{++i;
			if(i==10) break;
				wd.findElement(By.name("UserProfile")).click();
			}
			
		}
		
		catch(Exception e)
		{
			
		}
	}
	
	
	public static void uploadFile(String fileName) throws AWTException, InterruptedException
	{
		 String filePath=System.getProperty("user.dir")+"\\FilesToUpload\\"+fileName;
         System.out.println(filePath);
  		 StringSelection ss = new StringSelection(filePath);  
	     Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

	
	        java.awt.Robot robot = new java.awt.Robot();
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        Thread.sleep(1000);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_DOWN);
	        robot.keyRelease(KeyEvent.VK_DOWN);
	        Thread.sleep(2000);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        /*Thread.sleep(2000);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);*/
	}
	
	
	public static void hitEnterKey() throws AWTException, InterruptedException 
	{

	        java.awt.Robot robot = new java.awt.Robot();
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	}
	
	
	public static void hitDownKey() throws AWTException, InterruptedException 
	{

	        java.awt.Robot robot = new java.awt.Robot();
	        robot.keyPress(KeyEvent.VK_DOWN);
	        robot.keyRelease(KeyEvent.VK_DOWN);
	}
	
	
	
	public static void SelectCheckBox(WebDriver wd,String locator)
	{
		try{
		if(!getElement(wd, locator).isSelected())
			getElement(wd, locator).click();
		}
		catch(Throwable t)
		{
			exception="Failed to select check box";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
	}
	
	public static void selectProspectCompany(WebDriver wd,String locator)
	{
		try{
		prospectCompany=getElement(wd,locator).getText().trim();
		getElement(wd,locator).click();
		}
		catch(Throwable t)
		{
			exception="Failed  to select a company";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	public static void searchForCompany(WebDriver wd,String locator)
	{
		try{
			
		getElement(wd,locator).sendKeys(prospectCompany);
		}
		
		catch(Throwable t)
		{
			exception="Failed to search a company";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
	}
	public static void checkIfFiledIsActive(WebDriver wd,String locator,String status)
	{
		try{
		boolean  stat=getElement(wd,locator).isEnabled();
		if(stat)
			JavaLib.AssertEquals(wd, "Enabled", status, "Element is Enabled");
		else
			JavaLib.AssertEquals(wd, "Disabled", status, "Element is disabled");
		}
		catch(Throwable t)
		{
			exception="Element status is not as per the expectation";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	public static void selectPlanForAQuote(WebDriver wd,String planName )
	{
		try
		{
		wd.findElement(By.xpath("//*[text()='"+planName+"']/../../td[1]/span/input")).click();
		}
		catch(Throwable t)
		{
			exception="Failed to select a Plan";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			return;
		}
		
	}
	
	
	public static void validateSubGrp_GEFPlan(WebDriver wd)
	{
try{
			
			//Thread.sleep(300000);
		wd.findElement(By.xpath(".//*[@id='ctl00_lnkbtnDistSignOut']")).click();
    	wd.findElement(By.linkText("Agency One")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_hlMyClients']/b")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_txtClientName']")).sendKeys(prospectCompany);
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    	
    	
    	for(int i=0;i<20;i++)
    	{
    		try{if(wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).isDisplayed())
    			break;
    		}
    		catch(Exception e)
    		{
    			System.out.println("Subgroups are not yet created..waiting...");
    			//Thread.sleep(5000);
    			wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    		}
    	}
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).click();
    	
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_lst3']/a")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_SubgroupListing1_lvSubgroupListing_ctrl0_lnkSubGroupName']")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_tabSubgroupDetails']/li[2]/a")).click();
    	
    	wd.findElement(By.xpath(".//option[@selected='selected'][text()='H1 - UPMC FlexAdvantage HSA']")).isDisplayed();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_hlCancel']")).click();
/*    	
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_SubgroupListing1_lvSubgroupListing_ctrl0_lnkSubGroupName']")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_tabSubgroupDetails']/li[2]/a")).click();
    	
    	wd.findElement(By.xpath(".//option[@selected='selected' AND text()='H2 - Non-Administered']")).isDisplayed();*/
    	
    	  
		}
		catch(Throwable t)
		{
			exception="Failed to validate GEF plan";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
		
	}
	
	
	public static void selectActiveClient(WebDriver wd)
	{
		try{
			
			//Thread.sleep(300000);
		wd.findElement(By.xpath(".//*[@id='ctl00_lnkbtnDistSignOut']")).click();
    	wd.findElement(By.linkText("Agency One")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_hlMyClients']/b")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_txtClientName']")).sendKeys(prospectCompany);
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    	
    	
    	for(int i=0;i<20;i++)
    	{
    		try{if(wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).isDisplayed())
    			break;
    		}
    		catch(Exception e)
    		{
    			System.out.println("Subgroups are not yet created..waiting...");
    			//Thread.sleep(5000);
    			wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    		}
    	}
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).click();
		}
		catch(Throwable t)
		{
			exception="Failed to select active client";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}
	
	public static void activateSubGroup(WebDriver wd)
	{
		try{
			
			//Thread.sleep(300000);
		wd.findElement(By.xpath(".//*[@id='ctl00_lnkbtnDistSignOut']")).click();
    	wd.findElement(By.linkText("Agency One")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_hlMyClients']/b")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_txtClientName']")).sendKeys(prospectCompany);
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    	
    	
    	for(int i=0;i<20;i++)
    	{
    		try{if(wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).isDisplayed())
    			break;
    		}
    		catch(Exception e)
    		{
    			System.out.println("Subgroups are not yet created..waiting...");
    			//Thread.sleep(5000);
    			wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_btnSearch']")).click();
    		}
    	}
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucClientList_dgSearchResults_ctl03_lbtnQuoteOrgName']")).click();
    	
    	
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_lst3']/a")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_SubgroupListing1_lvSubgroupListing_ctrl0_lnkSubGroupName']")).click();
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_tabSubgroupDetails']/li[2]/a")).click();
    	
    	WebElement el=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_ddlGEFStatus']"));
    	
    	Select sel=new Select(el);
    	sel.selectByVisibleText("Active");
    	
    	el=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_ddlGEFSource']"));
    	
    	sel=new Select(el);
    	sel.selectByVisibleText("Platinum");
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_btnSave']")).click();
    	
    	wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_hlOk']")).click();
    

    	
    	int rows=wd.findElements(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_gvRateDetails']/tbody/tr")).size();
    	rates=new String[rows][3];
    	for(int i=0;i<rows-1;i++)
    	{
    		for(int j=0;j<rates[0].length;j++)
    		{
    			rates[i][j]=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_TobaccoOrNonTobaccoDetails_ascx_fvSubgroupTobaccoDetails_gvRateDetails']/tbody/tr["+(i+2)+"]/td["+(j+1)+"]")).getText();
    		}
    	}
            System.out.println();   
		}
		catch(Throwable t)
		{
			exception="Failed while activating subgroup";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
	}
	
	
	public static void validateRate(WebDriver wd,String element,String member)
	{
		
		/*rates[0][0]="40 - 40";
		rates[0][1]="$314.44";
		rates[1][0]="35-35";
		rates[1][1]="$300.67";
		rates[2][0]="0-20";
		rates[2][1]="$156.24";*/
		try{
			if(!member.equalsIgnoreCase("TotalRate"))
			{int age=0;
		
		String planstartDate=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucBenefitElection_lblMedPlanStartDateValue']")).getText();
		int startYear=Integer.parseInt(planstartDate.substring(0, 4));
		if(member.equalsIgnoreCase("Subscriber"))
		age=startYear-subscriber_DOB;
		else if(member.equalsIgnoreCase("Dependent1"))
			age=startYear-dependent1_DOB;
		else if(member.equalsIgnoreCase("Dependent2"))
			age=startYear-dependent2_DOB;
		else if(member.equalsIgnoreCase("Dependent3"))
			age=startYear-dependent2_DOB;
		
String expectedRate=null;
		
		for(int i=0;i<rates.length;i++)
		{
			String[] ages=rates[i][0].split("-");
			int startage=Integer.parseInt(ages[0].trim());
			int lastage=Integer.parseInt(ages[1].trim());
				
			if(age>=startage&&age<=lastage)
				{
				expectedRate=rates[i][1];
				String s1=expectedRate.substring(0,1);
				String s2=expectedRate.substring(2);
				expectedRate=s1+s2;
				totalRate=totalRate+Double.parseDouble(s2);
					break;
				}
				
		}
		System.out.println(expectedRate);
		SelLib.validatecheckPoint(wd,element, "text", expectedRate);}
			else 
				{
				
				DecimalFormat df = new DecimalFormat("#.##");
				SelLib.validatecheckPoint(wd,element, "text", ("$"+df.format(totalRate)));
				}
				
				
	}
		
		catch(Throwable t)
		{
			exception="Failed while reading and comparing rates";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
		
			
		}
	
	
	public static void validateHSA_ADmin_Sel_None(WebDriver wd)
	{
		try{Select sel=null;
		boolean flag=true;
	List<WebElement> hsa_Admin_Selection=	wd.findElements(By.xpath(".//*[contains(text(),'HIA PPO') or contains(text(),'Gold PPO') or contains(text(),'Silver PPO') or contains(text(),'Platinum PPO') or contains(text(),'HMO') or contains(text(),'HIA')or contains(text(),'EPO')]/../../td[3]/div/Select"));
	
	for(int i=0;i<hsa_Admin_Selection.size();i++)
	{
		boolean drpDwnActive=hsa_Admin_Selection.get(i).isEnabled();
		sel=new Select(hsa_Admin_Selection.get(i));
	String selected=sel.getFirstSelectedOption().getText();
	
	if((drpDwnActive==true)||(!selected.equalsIgnoreCase("None")))
	{
		flag=false;
		break;
	}
	
		
	}

	JavaLib.AssertBooleanEquals(wd, flag, true, "")	;
		}
		
		catch(Throwable t)
		{
			exception="Failed while validating HSA administration selection for HMO, PPO, EPO and HIA plans";
			ErrorUtils.addVerificationFailure(exception,wd,t);	
		}
		
	}
	
	
	public static void validate_HSAPlanDefaultSelection(WebDriver wd)
	{try{
		int hsa_Plans=wd.findElements(By.xpath(".//*[contains(text(),'HSA')]/../../td/span/input")).size();
		int hsa_PlansDefaultSelection=wd.findElements(By.xpath(".//*[contains(text(),'HSA')]/../../td[3]/div/Select/option[@selected='selected'][@value='0']")).size();
	
		JavaLib.AssertBooleanEquals(wd, (hsa_Plans==hsa_PlansDefaultSelection), true, "");
	}
	
	catch(Throwable t)
	{
		exception="Failed while validating HSA default selection";
		ErrorUtils.addVerificationFailure(exception,wd,t);	
	}
	
	}

	public static void selectBothHSAPlans(WebDriver wd)
	{
		try{
			//List<WebElement> selections=wd.findElements(By.xpath(".//*[text()='Select' AND @selected='selected']/../../../../td[1]/span/input"));
			//List<WebElement> hsaPlans=wd.findElements(By.xpath("//option[@selected='selected' AND @value='0']"));
			
			
			Select plan1=new Select(wd.findElement(By.xpath(".//*[contains(text(),'HSA PPO') ]/../../td[3]/div/Select")));
			wd.findElement(By.xpath(".//*[contains(text(),'HSA PPO') ]/../../td[1]/span/input")).click();
			plan1.selectByValue("2");
	
			
	
		}
		catch(Throwable t)
		{
			exception="Failed while selecting HSA  plans";
			ErrorUtils.addVerificationFailure(exception,wd,t);	
		}
	}
	
	//verify term reason of Employee and dependent

	/*public static void verifyTern(WebDriver wd,String locator,String validation) 
	{
		try
		{
		String empReason=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucBenefitElection_lvMedicalPlan_ctrl0_cmbTermReasonMed']")).getText();
		String depReason=wd.findElement(By.xpath(".//*[@id='ctl00_PageContent_ucBenefitElection_lvMedicalPlan_ctrl1_cmbTermReasonMed']")).getText();
		JavaLib.AssertBooleanEquals(wd, (empReason.equals(depReason)), false, "");
		
		
			Select sel=new Select(SelLib.getElement(wd, locator));
			String actR=sel.getFirstSelectedOption().getText();
			
			JavaLib.AssertEquals(wd, actR, validation, "Expected  option is not selected ");
			
		
		
		}
		catch(Throwable t)
		{
			exception="Failed to select expected value";
			ErrorUtils.addVerificationFailure(exception,wd,t);	
		}
	}*/

	public static void loginToApp(WebDriver wd,String locator,String input)
	{
		String[]locatorArray = JavaLib.splitToArray(locator);
		String[]inputArray = JavaLib.splitToArray(input);
		wd.findElement(By.xpath(locatorArray[1])).sendKeys(inputArray[0]);
		wd.findElement(By.xpath(locatorArray[2])).sendKeys(inputArray[1]);
		wd.findElement(By.xpath(locatorArray[3])).click();
	}

	
	
	public static void executeAction(WebDriver wd,String action,String element,String value,String validation,String expectation) throws NumberFormatException, InterruptedException
	{try{
		
		
		System.out.println(action +"="+element);
		switch(action)
		{
		case "Launch_Page":
			SelLib.openPage(wd,value);
			break;
		case "NavigateTo":
			SelLib.navigateTo(wd,value);
			break;
		case "Enter":
			SelLib.enterText(wd,element, value,validation);
			break;
		case "ClearText":
			SelLib.clearText(wd, element);
			break;
		
		case "LoginToApplication":
			SelLib.loginToApp(wd, element, value);
			break;	
			
		case "ClickOnMyProfile":
			SelLib.clickonMyProfile(wd,element);
			
		case "Click":
			SelLib.clickOnElement(wd,element);
			break;
			
		case "DoubleClick":
			SelLib.doubleClick(wd,element);
			break;
			
		case "SelectByText":
			SelLib.selectOptionbyText(wd,element, value);
			break;
		case "SelectByValue":
			SelLib.selectOptionbyValue(wd, element, value);
			break;
		
		case "Alert":
			SelLib.handleAlert(wd,validation);
			break;
		case "SwitchToLastWindow":
			SelLib.switchTolastChildWindow(wd);
			break;
		case "SwitchToParent":
			SelLib.switchToParentWindow(wd);
			break;
		case "SwitchToDefaultWindow":
			SelLib.switchToDefaultWindow(wd);
			break;
		case "SwitchToNthWindow":
			int n=Integer.parseInt(validation);
			SelLib.switchTonthChildWindow(wd,n);
			break;

		case "SwitchToFrameByName":
			String data[]=element.split("~");
			SelLib.switchToFramebyName(wd,data[1]);
			break;
		case "SwitchToFrameByIndex":
			String data1[]=element.split("~");
			int index=Integer.parseInt(data1[1]);
			SelLib.switchToFramebyIndex(wd,index);
			break;
		case "Validate":
			SelLib.validatecheckPoint(wd,element, validation, expectation);
			
			break;
		case "validateAlertpopup":
			SelLib.verifyAlertMsg(wd, expectation);
			break;


		case "SleepFor":
			int duration=Integer.valueOf(validation);
			Thread.sleep(duration);
			break;
		case "GetPageSource":
			System.out.println(wd.getPageSource());
			break;
		case "SelectDate":
		Page_EligibilityInformation.selectDateFromCalender(wd,element, validation);
		break;
		
		case "SelectCoverageLevel":
			Page_EmployeeInformation.select_CoverageLevel(wd, element, validation);
			break;
			
		case "SelectSuggestion":
			SelLib.selectSuggestion(wd, element);
			break;
			
		case "UploadFile":
			SelLib.uploadFile(validation);
			break;
			
		case "PressEnterKey":
			SelLib.hitEnterKey();
			break;
			
		case "PressDownKey":
			SelLib.hitDownKey();
			break;
				
		case "SelectCheckBox":
			SelLib.SelectCheckBox(wd, element);
			break;
			
		case "SelectProspectCompany":
			SelLib.selectProspectCompany(wd, element);
			break;
			
		case "SearchForCompany":
			SelLib.searchForCompany(wd, element);
			break;
			
		case "SelectPlan":
			SelLib.selectPlanForAQuote(wd, validation);
			break;
		case "ActivateSubGroup":
		SelLib.activateSubGroup(wd);
		break;
		
		case "ValidateRate":
			SelLib.validateRate(wd, element, validation);
			break;
			
		case "ValidateHSA_ADmin_Sel_None":
			SelLib.validateHSA_ADmin_Sel_None(wd);
			break;
		case "Validate_HSAPlanDefaultSelection":
			SelLib.validate_HSAPlanDefaultSelection(wd);
			break;
			
		case "Validate_SubGroup_GEF_Plan":
			SelLib.validateSubGrp_GEFPlan(wd);
			break;
		
		case "SelectBothHSAPlans":
			SelLib.selectBothHSAPlans(wd);
			break;
			
		case "CheckIfFiledIsActive":
			SelLib.checkIfFiledIsActive(wd, element, validation);
			break;
			
		case "SelectActiveClient":
			SelLib.selectActiveClient(wd);
			break;
			
		case "GetCensusDetails":
			Page_CensusDetails.getCensusDetails(wd);
			break;
			
		case "Getbenefitelections":
			Page_BenefitElections.getbenefitelections(wd);
			break;
			
		default: 
			System.out.println("Please define the action");
		}}
		
		catch(Throwable t)
		{
			exception="Failed while calling the action key";
			ErrorUtils.addVerificationFailure(exception,wd,t);
			
		}
			
		
	}
}
