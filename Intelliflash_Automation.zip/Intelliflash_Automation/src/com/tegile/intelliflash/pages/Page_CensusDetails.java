package com.tegile.intelliflash.pages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class Page_CensusDetails {
	public static List<String> censusDetails=new ArrayList<String>();
	public static HashMap<String,String> hmCensusDetails=new HashMap<String,String>();
	
	public static void getCensusDetails(WebDriver wd)
	{
		
		censusDetails.add("FirstName~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbFirstName']~value");
		censusDetails.add("LastName~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbLastName']~value");
		censusDetails.add("Gender~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlGender']~drpdwn");
		censusDetails.add("DOB~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbDateOfBirth']~value");
		censusDetails.add("Zip~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbZipCode']~value");
		censusDetails.add("County~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbCountyName']~value");
		censusDetails.add("Tobacco~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlTobaccoStatus']~drpdwn");
		censusDetails.add("CoverageType~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlCoverageTypes']~drpdwn");
		censusDetails.add("TobacoCessation~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlTobaccoCessasion']~drpdwn");
		censusDetails.add("Status~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlEmployeeStatus']~drpdwn");
		censusDetails.add("MiddleName~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtMiddleName']~value");
		censusDetails.add("Suffix~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_ddlSuffix']~drpdwn");
		censusDetails.add("SSN~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtSSN']~value");
		censusDetails.add("DateOfHire~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbDateOfHire']~value");
		censusDetails.add("StreetAddress1~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtStreetAddress1']~value");
		censusDetails.add("StreetAddress2~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtStreetAddress2']~value");
		censusDetails.add("PhoneNo~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtMainPhoneNUmber']~value");
		censusDetails.add("Extension~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtExtension']~value");
		censusDetails.add("Email~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_tbEmail']~value");
		censusDetails.add("PCP~.//*[@id='ctl00_PageContent_lvCensusDetails_ctrl0_txtPCP']~value");
		
		
		Select sel=null;
		for(int i=0;i<censusDetails.size();i++)
		{
			String info=censusDetails.get(i);
			String[] data=info.split("~");
			if(!data[2].equalsIgnoreCase("drpdwn"))
				hmCensusDetails.put(data[0], wd.findElement(By.xpath(data[1])).getAttribute(data[2]));
			else
			{
				sel=new Select(wd.findElement(By.xpath(data[1])));
				hmCensusDetails.put(data[0], sel.getFirstSelectedOption().getText());
			}
				
			
		}
		
		
	}
	

}
