package com.tegile.intelliflash.testdriver;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.tegile.intelliflash.init.App_Log;
import com.tegile.intelliflash.init.Init;
import com.tegile.intelliflash.init.Init_WebDriver;
import com.tegile.intelliflash.listeners.ErrorUtils;
import com.tegile.intelliflash.utils.JavaLib;
import com.tegile.intelliflash.utils.SelLib;


public class TestCaseDriver extends Init_WebDriver {
	
	public static String client="";
	
	
	//public static String result="Passed";
	public String testCaseName="";
	public static int totalStepsFailed=0;
	public static int totalTestCases=0;
	public static int totalTestCasesP=0;
	public static int totalTestCasesF=0;
	public static int totalTestCasesS=0;
	
	public static int totalTCPassed=0;
	public static int totalTCFailed=0;
	public static int totalTCSkipped=0;
	
	public String scrnFrPass;
	public static String sDate="";
	static DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	static Date date = new Date();
	public static List<WebDriver> wds=new ArrayList<WebDriver>();
	
	
	
	public  boolean skip=false;
	
	 public WebDriver wd;
	 
	  public String browser;
  public String version;
  public String platform;
  
  public StringBuilder sb1;
	
@BeforeTest
	  public void set()
	  {
	    sb1=new StringBuilder();
	    totalStepsFailed=0;
	  skip=false;
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\1000248873\\Downloads\\chromedriver_win32\\chromedriver.exe");
		  wd=new ChromeDriver();
		  
		  wd.manage().deleteAllCookies();
		  wd.manage().timeouts().pageLoadTimeout(120000, TimeUnit.MILLISECONDS);
		  wd.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
		  wd.manage().window().maximize();
	  }
  
  
/*@BeforeTest
  @org.testng.annotations.Parameters(value={"browser","version","platform"})
  public void setUp(String browser, String version, String platform) throws Exception {
	  sb1=new StringBuilder();
	  totalStepsFailed=0;
	  skip=false;
	  this.browser=browser;
	  this.version=version;
	  this.platform=platform;
    DesiredCapabilities capability = new DesiredCapabilities();
    capability.setCapability("platform",platform);
    capability.setCapability("browserName", browser);
    capability.setCapability("browserVersion", version);
    capability.setCapability("browserstack.debug", "true");

    wd = new RemoteWebDriver(new URL("http://michaelbell4:7BoYPPBBbMgwx2kTdG1z@hub.browserstack.com/wd/hub"),capability);
  	wd.manage().timeouts().pageLoadTimeout(60000, TimeUnit.MILLISECONDS);
		  wd.manage().timeouts().implicitlyWait(60000, TimeUnit.MILLISECONDS);
		  wd.manage().window().maximize();

}*/
	  
      public void test1(String arg)
      {
    	  System.out.println(arg);
      }




	    @AfterTest
	  public void teardown()
	  {
	    	if(totalStepsFailed>0)
			{
				++totalTestCasesF;
			}
	    	else if(!skip)
	    	++totalTestCasesP;
			
	    
	    	APP_LOGS.debug("----------sb1---------");
	    	 APP_LOGS.debug(sb1);
	    sb.append(sb1);
	  
		  wd.quit();
	  }
	
	
	@Parameters({"TestCase","ClientSheet"})
	@Test
	public void testMethod(String testcase,String clientSheet) throws IOException, NumberFormatException, InterruptedException
	{
	App_Log.startTestCase(testcase);
	try{ErrorUtils.error="";
	ErrorUtils.imgefileName="";
	//scrnFrPass="-";
	
	//totalStepsFailed=0;
	++totalTestCases;
	testCaseName=testcase;
	System.out.println(testcase);
	test1(testcase);
		client=clientSheet.split("_")[1];
		
		Object[][] locatorSheetData=JavaLib.getInputSheetData("TestDriverWorkBook", "LocatorDetails");
		Object[][] masterSheetData=JavaLib.getInputSheetData("TestDriverWorkBook", clientSheet);
	

		Object[][] testInputSheetData=JavaLib.getInputSheetData("TestDriverWorkBook", "TestInput");
	
		String action=null;
		String elementLocator=null;
		String inputData=null;
		String validation=null;
		String expected=null;
		String description=null;
		boolean executing=false;
		String errorInfo="";
		
		//----------------------------------------------------
		
		for(int i=1;i<masterSheetData.length;i++)
		{
			ErrorUtils.error="";
			ErrorUtils.imgefileName="";
			scrnFrPass="-";
			boolean testStepfFailed=false;
			if(totalStepsFailed==1) break;
			for(int j=0;j<wds.size();j++)
			{
				if(wds.contains(wd))
					testStepfFailed=true;
					
			}
			
			if(testStepfFailed) break;
			if(masterSheetData[i][1].toString().equals(testcase))
			{try{
				
				if(masterSheetData[i][2].toString().equalsIgnoreCase("N"))
				
				{
					++totalTestCasesS;
					throw new SkipException("Choosen to skip this test case execution");
				
				}}
			
			catch(Exception e)
			{
				skip=true;
				JavaLib.addToReport(skip,sb1,testCaseName, "Execution is skipped ", "Skipped", "Execution is skipped","-");
				test1("Skipped");
			break;
			}
				
				
				
					executing=true;
				
				
			}
			
			else if(masterSheetData[i][4].toString()!=null)
				if(masterSheetData[i][4].toString().length()==0 && executing)
			{
				
			}
			else if(masterSheetData[i][4].toString()==null && executing)
				{
					
				}
				
			else if(executing)
			break;
			else
				continue;
			
			//---------------------------------------------------------
				
			action=masterSheetData[i][7].toString();
			description=masterSheetData[i][6].toString();
			
			if(action.equalsIgnoreCase("END"))
				break;
			validation=masterSheetData[i][9].toString();
			expected=masterSheetData[i][10].toString();
			
		//------------------------------------------------------------	
			{
			for(int j=1;j<locatorSheetData.length;j++){
				
				if(locatorSheetData[j][1].toString().equals(masterSheetData[i][8].toString()))
						{
					if(locatorSheetData[j][5].toString()==null || locatorSheetData[j][5].toString().length()==0 )
						errorInfo="Element not found";
					else
					errorInfo=locatorSheetData[j][5].toString();
					
				elementLocator	=locatorSheetData[j][3].toString()+"~"+locatorSheetData[j][4].toString()+"~"+errorInfo;
						}
					}
			if (elementLocator==null)
				elementLocator=masterSheetData[i][8].toString();
			}
		//--------------------------------------------	
			{
				for(int j=1;j<testInputSheetData.length;j++){
					
					if(testInputSheetData[j][1].toString().equals(masterSheetData[i][9]))
							{
					
					System.out.println(testInputSheetData[0][1].toString());
					System.out.println(testInputSheetData[j][1].toString());
					System.out.println(masterSheetData[0][9]);
					System.out.println(masterSheetData[i][9]);
					inputData=testInputSheetData[j][2].toString();
					System.out.println(j+"j value");
					System.out.println(inputData);
					break;
							}
						}
				if (inputData==null)
					inputData="";
				}
		
			if(elementLocator.contains("linkText~clientLink"))
		SelLib.executeAction(wd,action, "linkText~"+client+"~Client name is not present in Client",inputData,validation,expected);
			else		
		System.out.println(inputData);
		System.out.println(elementLocator);
		SelLib.executeAction(wd,action, elementLocator,inputData,validation,expected);
			
			if(ErrorUtils.error.equals("")){
				if(masterSheetData[i][11].toString().equalsIgnoreCase("Y"))
				{
				++ErrorUtils.n;
				sDate=dateFormat.format(date).replace('/', '_').replace(':', '_');
				scrnFrPass=ErrorUtils.n+"ScrnShot_"+sDate;
				scrnFrPass=scrnFrPass.replace(" ", "");
				SelLib.takeScreenshot(wd,scrnFrPass);	
			JavaLib.addToReport(skip,sb1,testCaseName, description, "Passed", "-",scrnFrPass);
			test1("pass");
			}
				else
					JavaLib.addToReport(skip,sb1,testCaseName, description, "Passed", "-",scrnFrPass);
				test1("pass");
			}
			else
			{
				++ErrorUtils.n;
				sDate=dateFormat.format(date).replace('/', '_').replace(':', '_');
				scrnFrPass=ErrorUtils.n+"ScrnShot_"+sDate;
				scrnFrPass=scrnFrPass.replace(" ", "");
				SelLib.takeScreenshot(wd,scrnFrPass);
				test1("Failed");
				if(ErrorUtils.error.contains("Expected")||ErrorUtils.error.contains("lement"))
				JavaLib.addToReport(skip,sb1,testCaseName, description, "Failed", ErrorUtils.error,scrnFrPass);
				
				else
					JavaLib.addToReport(skip,sb1,testCaseName, description, "Failed", description +" step is failed",scrnFrPass);	
				//JavaLib.addToReport(skip,sb1,testCaseName, description, "Failed", ErrorUtils.error,ErrorUtils.imgefileName);
				test1("Failed");
				
			}
			testCaseName=" ";	
		}
		if(skip)
			return;
		
				
			
		}
		catch(Throwable t)
		{
			ErrorUtils.addVerificationFailure("TestCase failed",wd,t);
			
		}
		}

	}










