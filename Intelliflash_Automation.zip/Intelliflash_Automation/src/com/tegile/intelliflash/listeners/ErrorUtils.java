package com.tegile.intelliflash.listeners;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.Reporter;

import com.tegile.intelliflash.testdriver.TestCaseDriver;
import com.tegile.intelliflash.utils.SelLib;

/**
 * @author Manas Ranjan Mohanty
 *
 */

public class ErrorUtils {
	private static Map<ITestResult,List> verificationFailuresMap = new HashMap<ITestResult,List>();
	private static Map<ITestResult,List> skipMap = new HashMap<ITestResult,List>();
	public static String error="";
	public static String  imgefileName="";
	public static int n=0;
	static DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	static Date date = new Date();
	static String cDate="";
	public static void addVerificationFailure(String errorM,WebDriver wd,Throwable e) {
if(!TestCaseDriver.wds.contains(wd))//if(error== null || error.equals(""))
		{
			System.out.println("Screenshot");
			//++n;
			/*cDate=dateFormat.format(date).replace('/', '_').replace(':', '_');
			imgefileName=n+"ScrnShot_"+cDate;
			imgefileName=imgefileName.replace(" ", "");*/
			//SelLib.takeScreenshot(wd,imgefileName);
	//error=SelLib.exception;
			error=errorM;
	TestCaseDriver.totalStepsFailed=TestCaseDriver.totalStepsFailed+1;
	TestCaseDriver.wds.add(wd);
		}
	List verificationFailures = getVerificationFailures();
	verificationFailuresMap.put(Reporter.getCurrentTestResult(), verificationFailures);
	verificationFailures.add(e);
	}
	 
	public static List getVerificationFailures() {
	List verificationFailures = verificationFailuresMap.get(Reporter.getCurrentTestResult());
	return verificationFailures == null ? new ArrayList() : verificationFailures;
	} 
}

