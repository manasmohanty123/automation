package com.tegile.intelliflash.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.tegile.intelliflash.utils.SelLib;

public class Page_EmployeeInformation {
	
	public static void select_CoverageLevel(WebDriver wd,String element,String coverage){
		Select sel=new Select(SelLib.getElement(wd, element));
		List<WebElement> options=sel.getOptions();
		boolean present=false;
		for(int i=0;i<options.size();i++)
		{
			if(options.get(i).getText().equalsIgnoreCase(coverage))
			{
				sel.selectByVisibleText(coverage);
				present=true;
				break;
			}
			
		}
		if(!present)
		sel.selectByVisibleText("EE");
	}

}
