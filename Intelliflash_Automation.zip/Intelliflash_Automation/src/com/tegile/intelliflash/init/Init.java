package com.tegile.intelliflash.init;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.tegile.intelliflash.testdriver.TestCaseDriver;
import com.tegile.intelliflash.utils.JavaLib;

public class Init {
	
	public static int totalSuites=0;
	public static int runningSuite=0;
	public static boolean flag=false;
	public static Properties propConfig=null;
	public static Properties propOR=null;
	public static Logger APP_LOGS=Logger.getLogger("devpinoyLogger");
	
	public static StringBuilder sb = new StringBuilder();
	public static StringBuilder tb = new StringBuilder();
	public static StringBuilder rb = new StringBuilder();
	public static FileWriter fWriter = null;
	public static BufferedWriter writer = null;
	public static String fileName;
	Date executionStartTime;
	Date executionEndTime;
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	public static String executionEnv;
	public static String executionbuildVersion;

	
	
	
	
	@BeforeSuite
	public void areadConfigProperties() throws IOException
	{
		executionStartTime = new Date();
		
		
		if(propConfig==null)
		{
		String propFilePath=System.getProperty("user.dir")+"\\src\\com\\tegile\\intelliflash\\configuration\\config.properties";
		propConfig=new Properties();
		FileInputStream fi=new FileInputStream(propFilePath); 
		propConfig.load(fi);
		}
		}
	
	
	@BeforeSuite
	public static void bgetTotalNoOfSuites() throws IOException
	{
		runningSuite=runningSuite+1;
		if(flag)
			return;
		else flag=true;
		Object[][] client_Executionstatus=JavaLib.getInputSheetData("TestDriverWorkBook", "Executable_Suites");
			
		Hashtable<String ,String> execution=new Hashtable<String,String>();
		
		for(int i=0;i<client_Executionstatus.length;i++)
		{
				execution.put(client_Executionstatus[i][0].toString(), client_Executionstatus[i][1].toString());	
		}
		
	String masterExcelLoc =Init.propConfig.getProperty("TestWorkBooks");
    FileInputStream file = new FileInputStream(System.getProperty("user.dir")+masterExcelLoc+"TestDriverWorkBook"+".xlsx");
	
	XSSFWorkbook workbook = new XSSFWorkbook(file);
    
   int m=0;
   String sheetName="";
   List<String> clients=new ArrayList<String>();
   while(sheetName!=null)
   {
  	 try{
  	 sheetName=workbook.getSheetName(m++);
  	 if(sheetName.contains("Client")&& execution.get(sheetName).equalsIgnoreCase("Y"))
  			
  	 clients.add(sheetName);
  			 
  	 }
  	 catch(Exception e)
  	 {
  		 break;
  	 }
  	 //System.out.println(sheetName); 
   }
	
   totalSuites= clients.size();
	}
	
	@Parameters({"ClientSheet"})
	@BeforeSuite
	public static void createReportFile(String ClientSheet) throws IOException
	{
		if(runningSuite==1)
		{
			 sb.append("<ul>");
			 
			File dir=new File(System.getProperty("user.dir")+"\\Sel_HTML_Reports");
			File[] children = dir.listFiles();
			for (int i = 0; i < children.length; i++) 
			{ String fileName=children[i].getName();
			if((fileName.contains("ExecutionReport")||fileName.contains("ScrnShot")) && (!fileName.contains("Logo")))
				children[i].delete();}
		}
		if(runningSuite==totalSuites)
		{
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		String cDate=dateFormat.format(date).replace('/', '_').replace(':', '_');
		fileName=System.getProperty("user.dir")+"\\Sel_HTML_Reports\\Intelliflash_Selenium_ExecutionReport_"+cDate+".html";
		 File file = new File(fileName);
		 file.createNewFile();
	}
		String testSuiteName=ClientSheet.split("_")[1];
		sb.append(" <li><span class=\"Collapsable\">"+testSuiteName+"</span><a href=\"#top\"> ...Go to summary</a>");
		    sb.append("<table border='1' style=\"width:80%\">");
		    sb.append("<caption>Results for "+testSuiteName+"</caption>");
		    sb.append("<tr><th>TestCaseName</th><th>StepDescription</th><th>StepResult</th><th>Error</th><th>Screenshots</th></tr>");
	}
	
	

	
	@Parameters({"ClientSheet"})
	@AfterSuite
	public void updateReportFile(String ClientSheet) throws Exception
	{
		executionEndTime = new Date();
		
		TestCaseDriver.totalTCPassed=TestCaseDriver.totalTCPassed+TestCaseDriver.totalTestCasesP;
		TestCaseDriver.totalTCFailed=TestCaseDriver.totalTCFailed+ TestCaseDriver.totalTestCasesF;
		TestCaseDriver.totalTCSkipped=TestCaseDriver.totalTCSkipped+TestCaseDriver.totalTestCasesS;
		
		if(runningSuite==1)
		{ 	rb.append("<table border='1'>");
		rb.append("<tr><td>");
			rb.append("<table border='1'>");
			rb.append("<caption id=\"top\">Execution Summary report</caption>");
			rb.append("<tr><th>TestSuiteName</th><th>Total TCs</th><th>Total Passed</th><th>Total Failed</th><th>Total Skipped</th></tr>");	
		}
		
		rb.append("<tr><td>"+ClientSheet+"</td><td>"+ TestCaseDriver.totalTestCases+"</td><td>"+TestCaseDriver.totalTestCasesP+"</td><td>"+ TestCaseDriver.totalTestCasesF+"</td><td>"+TestCaseDriver.totalTestCasesS+"</td></tr>");
		sb.append("</table>");
		sb.append("</li>");
		sb.append("</br>");
		
		 if(runningSuite==totalSuites)
		    {
		    	
		    	tb.append("<html>");
				tb.append("<head>");
				tb.append("<title>Intelliflash UI Automation test execution report</title>");
				tb.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />");
				tb.append("<script type=\"text/javascript\" src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js\"></script>");
				tb.append("<script type=\"text/javascript\" src=\"https://www.google.com/jsapi\"></script>");
				 
				tb.append("<script type=\"text/javascript\">");
				 
				tb.append(" google.load(\"visualization\", \"1\", {packages:[\"corechart\"]});");
				tb.append("google.setOnLoadCallback(drawChart);");
				tb.append(" function drawChart() {");
				tb.append(" var data = google.visualization.arrayToDataTable([");
				tb.append(" ['Type', 'Total'], ['Passed', "+TestCaseDriver.totalTCPassed+"], ['Failed',  "+TestCaseDriver.totalTCFailed+"], ['Skipped',  "+TestCaseDriver.totalTCSkipped+"]");
				tb.append("  ]);");
				tb.append(" var options = { title: 'Test suites overview' };");
				tb.append(" var chart = new google.visualization.PieChart(document.getElementById('piechart'));");
				tb.append("chart.draw(data, options);}");
				tb.append("</script>");
				tb.append("</head>");
				tb.append("<body bgcolor=\"#E6E6FA\">");
				tb.append("<table><tr><td>");
				tb.append("<div><img src=\"TegileLogo.jpg\" style=\"width:100px;height:100px;\"></td>");
				tb.append("<td><h2>Intelliflash UI Automation execution Report</h2></td></tr>");
				tb.append("<tr><td><i>Execution started at= "+dateFormat.format(executionStartTime)+"</i></td></tr>");
				tb.append("<tr><td><i>Execution completed at= "+dateFormat.format(executionEndTime)+"</i></td></tr>");	
				tb.append("<tr><td><i>Executed By Manas Ranjan Mohanty</i></td></tr>");	
				long diff = executionEndTime.getTime() - executionStartTime.getTime();
				System.out.println(diff);

				long diffSeconds = diff / 1000 % 60;
				long diffMinutes = diff / (60 * 1000) % 60;
				long diffHours = diff / (60 * 60 * 1000) % 24;
				long diffDays = diff / (24 * 60 * 60 * 1000);
				
				tb.append("<tr><td>Execution time= "+diffDays+" Days:"+diffHours+" Hours:"+diffMinutes+" Minutes:"+diffSeconds+" Seconds</td></tr>");
				tb.append("<tr><td><i>Execution Environment= "+executionEnv+"</i></td></tr>");
				tb.append("<tr><td><i>Build Version = "+executionbuildVersion+"</i></td></tr></table>");
				tb.append("</br>");
				
				rb.append("</table>");
				rb.append("</td>");
				rb.append("<td valign=\"top\">");
				rb.append("<div id=\"piechart\" style=\"width: 900px; height: 500px;\"></div>");
				rb.append("</td></tr>");
				rb.append("</table>");
				
				
				sb.append("</ul>");
				sb.append("<script type=\"text/javascript\">");
				sb.append(" $(\".Collapsable\").click(function () {");
				sb.append("$(this).parent().children().toggle();");
				sb.append(" $(this).toggle();")	;
			     sb.append(" });") ;
			     sb.append("</script>");
			       

			   
				
		
			sb.append("</body>");
			sb.append("</html>");
			 	fWriter = new FileWriter(fileName);
			    writer = new BufferedWriter(fWriter);
			    writer.write(tb.toString());
			    writer.write(rb.toString());
			    writer.write(sb.toString());
			   
			    writer.close(); 
			    JavaLib.zipReportFolder();
		    }
		

			TestCaseDriver.totalTestCases=0;
		    TestCaseDriver.totalTestCasesP=0;
		    TestCaseDriver.totalTestCasesF=0;
		    TestCaseDriver.totalTestCasesS=0;
		    MAILTest.send();
		
	}
	
	@BeforeSuite
	public static void setLog4j()
	{
		APP_LOGS=Logger.getLogger("devpinoyLogger");
		//String log4jConfPath = System.getProperty("user.dir")+"/src/log4j.properties";
		//PropertyConfigurator.configure(log4jConfPath);
	}
	
	
	
}
