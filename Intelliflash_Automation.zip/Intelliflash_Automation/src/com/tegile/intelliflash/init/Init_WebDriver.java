package com.tegile.intelliflash.init;

import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.tegile.intelliflash.utils.JavaLib;



public class Init_WebDriver extends Init {
	
	//public static WebDriver wd=null;
	
	/*@BeforeTest
	public void setUp_WebDriver() throws IOException
	{
		 
		//if(wd==null)
		{
		
		if(Init.propConfig.getProperty("browser").equalsIgnoreCase("FF"))
		{
			wd=new FirefoxDriver();
		

		}
		else if(Init.propConfig.getProperty("browser").equalsIgnoreCase("chrome"))
		{
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\DriverExe\\chromedriver.exe");
		wd=new ChromeDriver();
		}
		else if(Init.propConfig.getProperty("browser").equalsIgnoreCase("ie"))
		{
		
		System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")+"\\DriverExe\\IEDriverServer.exe");
		wd=new InternetExplorerDriver();
		}
		
		wd.manage().window().maximize();
		wd.manage().timeouts().implicitlyWait(30000, TimeUnit.MILLISECONDS);
		wd.manage().timeouts().pageLoadTimeout(30000, TimeUnit.MILLISECONDS);
		}
	}
	*/

	
/*	@AfterTest
	public void tearDown() throws Exception
	{
		wd.quit();
		
		
	}*/
	
}
